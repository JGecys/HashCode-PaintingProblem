package drawables;

public interface Drawable {

    void Draw(Painting painting);


}
