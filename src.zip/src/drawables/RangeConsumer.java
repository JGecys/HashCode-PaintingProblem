package drawables;

public interface RangeConsumer {

    void at(Position pos);

}
